package apd67.ir.cfg;

public class CFGNode {
  // private IRBlock body;
  // private String label;

  // public CFGNode(IRBlock block) {
  //   body = block;

  // }

  // public LinkedList<CFGNode> getNeighborsOut() {

  // }

  // public LinkedList<CFGNode> getNeighborsIn() {

  // }
}

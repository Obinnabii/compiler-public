/** Common utilities for Cornell CS 4120 */
package apd67.util.cs4120;

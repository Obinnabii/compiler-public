package apd67.ast;

/** Class to represent any expression that involves two expressions (Binop + Array Access) */
public abstract class Binary extends Expr {}

package apd67.ast;

public abstract class Stmt extends Node {}

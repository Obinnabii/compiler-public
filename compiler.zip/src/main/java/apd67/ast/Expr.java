package apd67.ast;

public abstract class Expr extends Node implements Variable {}
